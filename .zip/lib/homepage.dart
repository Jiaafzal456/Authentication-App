import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _noteController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isDarkTheme = true;
  bool _isProfileExpanded = false;
  int _notificationCount = 0;

  Future<void> _logout() async {
    await _auth.signOut();
    if (context.mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  Future<void> _addNote() async {
    final user = _auth.currentUser;
    if (user != null && _noteController.text.trim().isNotEmpty) {
      await _firestore.collection('notes').add({
        'userId': user.uid,
        'text': _noteController.text.trim(),
        'createdAt': Timestamp.now(),
      });
      _noteController.clear();
    }
  }

  Future<void> _editNote(String docId, String currentText) async {
    final TextEditingController _editController = TextEditingController(text: currentText);

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _isDarkTheme ? const Color(0xFF2F3145) : Colors.grey[200],
        title: Text('Edit Note', style: TextStyle(color: _isDarkTheme ? Colors.white : Colors.black)),
        content: TextField(
          controller: _editController,
          style: TextStyle(color: _isDarkTheme ? Colors.white : Colors.black),
          decoration: InputDecoration(
            hintText: "Write Something Here",
            hintStyle: TextStyle(color: _isDarkTheme ? Colors.white54 : Colors.grey),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: _isDarkTheme ? Colors.white : Colors.black)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6A5AE0)),
            onPressed: () async {
              if (_editController.text.trim().isNotEmpty) {
                await _firestore.collection('notes').doc(docId).update({
                  'text': _editController.text.trim(),
                });
              }
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteNote(String docId) async {
    await _firestore.collection('notes').doc(docId).delete();
  }

  void _toggleTheme() {
    setState(() {
      _isDarkTheme = !_isDarkTheme;
    });
  }

  void _toggleProfile() {
    setState(() {
      _isProfileExpanded = !_isProfileExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    final userEmail = user?.email ?? 'User';
    final backgroundColor = _isDarkTheme ? const Color(0xFF1F2235) : Colors.white;
    final textColor = _isDarkTheme ? Colors.white : Colors.black;
    final secondaryColor = _isDarkTheme ? const Color(0xFF2F3145) : Colors.grey[300];
    final accentColor = const Color(0xFF6A5AE0);

    return Theme(
      data: _isDarkTheme ? ThemeData.dark() : ThemeData.light(),
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          backgroundColor: _isDarkTheme ? const Color(0xFF1F2235) : Colors.grey[100],
          elevation: 2,
          title: Text('Home', style: TextStyle(color: textColor)),
          actions: [
            IconButton(
              icon: Stack(
                children: [
                  const Icon(Icons.notifications, color: Colors.white),
                  if (_notificationCount > 0)
                    Positioned(
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          '$_notificationCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
              onPressed: () {
                setState(() {
                  _notificationCount = _notificationCount + 1;
                });
              },
            ),
            IconButton(
              icon: const Icon(Icons.brightness_6, color: Colors.white),
              onPressed: _toggleTheme,
            ),
            IconButton(
              icon: const Icon(Icons.account_circle, color: Colors.white),
              onPressed: _toggleProfile,
            ),
          ],
        ),
        body: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome, $userEmail!',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 30),
                  TextField(
                    controller: _noteController,
                    style: TextStyle(color: textColor),
                    decoration: InputDecoration(
                      labelText: "Add a note",
                      labelStyle: TextStyle(color: _isDarkTheme ? Colors.white70 : Colors.black54),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.send, color: accentColor),
                        onPressed: _addNote,
                      ),
                      filled: true,
                      fillColor: secondaryColor,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: accentColor),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  StreamBuilder<QuerySnapshot>(
                    stream: _firestore
                        .collection('notes')
                        .where('userId', isEqualTo: user?.uid)
                        .orderBy('createdAt', descending: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const CircularProgressIndicator(color: Colors.white);
                      }

                      final notes = snapshot.data!.docs;

                      if (notes.isEmpty) {
                        return Text(
                          "No notes yet.",
                          style: TextStyle(color: _isDarkTheme ? Colors.white70 : Colors.black54),
                        );
                      }

                      return ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: notes.length,
                        itemBuilder: (context, index) {
                          final note = notes[index];
                          final docId = note.id;
                          final text = note['text'];
                          final createdAt = note['createdAt'].toDate().toString();

                          return Card(
                            color: secondaryColor,
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 4,
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(12),
                              title: Text(
                                text,
                                style: TextStyle(color: textColor),
                              ),
                              subtitle: Text(
                                createdAt,
                                style: TextStyle(fontSize: 12, color: _isDarkTheme ? Colors.white70 : Colors.black54),
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.edit, color: textColor),
                                    onPressed: () => _editNote(docId, text),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete, color: Colors.redAccent),
                                    onPressed: () => _deleteNote(docId),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
            if (_isProfileExpanded)
              GestureDetector(
                onTap: _toggleProfile,
                child: Container(
                  color: Colors.black26,
                  child: Center(
                    child: Card(
                      color: secondaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 8,
                      margin: const EdgeInsets.all(20),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircleAvatar(
                              radius: 40,
                              backgroundColor: accentColor,
                              child: Text(
                                userEmail[0].toUpperCase(),
                                style: const TextStyle(fontSize: 24, color: Colors.white),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              userEmail,
                              style: TextStyle(fontSize: 18, color: textColor, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: accentColor),
                              onPressed: _logout,
                              child: const Text('Logout'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}